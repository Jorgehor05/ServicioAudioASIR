menu() {
	while true; do
		clear
		echo "---------------------------------------------------------"
		echo "| Servicio de Audio Script realizado por Jorge del Horno |"
		echo "---------------------------------------------------------"
		echo "0. Conocer la informacion del equipo/red"
		echo "1. Conocer el status de pulseaudio"
		echo "2. Instalar Pulseaudio"
		echo "3. Eliminar Pulseaudio"
		echo "4. Iniciar Pulseaudio"
		echo "5. Detener Pulseaudio"
		echo "6. Desactivar PipeWire"
		echo "7. Activar Pipewire"
		echo "8. Consultar Logs"
		echo "	8.1 por Fecha"
		echo "	8.2 por Tipo"
		echo "9. Salir"
	read -p "Elige una opcion:" opcion
	case $opcion in
		0) echo ""
		echo -e "\e[38;5;75mEsta es la informacion de red del pc:\e[0m"
		echo "Direccion IP: $(hostname -I | awk '{print $1}')"
		echo "Nombre del host: $(hostname)"
		echo "Interfaz de red: $(ip route | grep default | awk '{print $5}')"
		echo ""
		;;

		1) echo ""
		echo -e "\e[38;5;75mEste es el status de pulseaudio actualmente..\e[0m"
		SERVICIO="pulseaudio"
		VERSION=$(pulseaudio --version 2>/dev/null)

		if [ -n "$VERSION" ]; then
			echo -e "\e[31m$SERVICIO esta activado con esta version: $VERSION\e[0m"
		else
			echo -e "\e[31m$SERVICIO no esta activado\e[0m"
		fi
		echo ""
		;;

		2) echo ""
		SERVICIO="pulseaudio"
                VERSION=$(pulseaudio --version 2>/dev/null)

                if [ -n "$VERSION" ]; then
                        echo -e "\e[31m$SERVICIO esta activado con esta version: $VERSION\e[0m"
                else
                        echo -e "\e[38;5;75mInstalando Pulseaudio ..\e[0m"
               		sudo apt update && sudo apt install -y pulseaudio pavucontrol paprefs pulseaudio-utils telnet ufw mpv
                	echo ""
               	 	echo "pulseaudio se ha intalado correctamente"
                	echo ""
                fi
		;;
		3) echo""
		echo -e "\e[38;5;75mEliminando Pulseaudio, Paprefs, Pulseaudio-utils, Pavucontrol ..\e[0m"
		echo ""
		sudo dpkg --configure -a
                sudo apt install -f -y
		sudo apt remove --purge -y pulseaudio pulseaudio-utils pavucontrol paprefs libpulse0 mpv libavdevice60 libavfilter9
		sudo apt autoremove -y && sudo apt clean
		sudo rm -rf /var/lib/dpkg/lock
		sudo rm -rf /var/lib/dpkg/lock-frontend
		sudo rm -rf /var/lib/apt/lists/*
		sudo rm -rf /var/cache/apt/archives/*.deb
		sudo apt update --fix-missing
		sudo apt upgrade -y
		echo ""
		echo "Borrando la configuracion y archivos"
		echo ""
		sudo rm -rf ~/.config/pulse ~/.pulse /etc/pulse /var/lib/pulse

		ELIMINAR=$(dpkg -l | grep pulseaudio)
		if [ -z "$ELIMINAR" ]; then
			echo "Se ha eliminado correctamente"
		else 
			echo "No se ha eliminado correctamente"
		fi
		;;
		4)echo ""
		if pgrep -x "pulseaudio" > /dev/null; then
			echo -e "\e[38;5;75mPulseaudio ya esta en ejecucion\e[0m"
		else
			echo -e "\e[38;5;75mIniciando Pulseaudio ..\e[0m"
		systemctl --user start pulseaudio.service
                systemctl --user start pulseaudio.socket
                echo "Pulseaudio se ha iniciado"
		fi
		;;
		5)echo ""
		if pgrep -x "pulseaudio" > /dev/null; then
                	 echo -e "\e[38;5;75mDeteniendo Pulseaudio ..\e[0m"
			systemctl --user stop pulseaudio.service
			systemctl --user stop pulseaudio.socket
			killall pulseaudio 2>/dev/null
			echo "Pulseaudio se ha detenido"
		else
			echo -e "\e[38;5;75mPulseaudio ya esta detenido\e[0m"
		fi
		;;
		6) echo ""
		if pgrep -x "pipewire" > /dev/null; then
                         echo -e "\e[38;5;75mDesactivando pipewire ..\e[0m"
			systemctl --user stop pipewire.service
			systemctl --user stop pipewire.socket
			systemctl --user stop pipewire-pulse.service
			systemctl --user stop pipewire-pulse.socket

                        systemctl --user disable pipewire.service
                        systemctl --user disable pipewire.socket
                        systemctl --user disable pipewire-pulse.service
                        systemctl --user disable pipewire-pulse.socket

                        systemctl --user mask pipewire.service
                        systemctl --user mask pipewire.socket
                        systemctl --user mask pipewire-pulse.service
                        systemctl --user mask pipewire-pulse.socket
			echo "Pipewire se ha desactivado"
		else
			echo "Pipewire ya esta desactivado"
		fi
 		;;

		7) echo ""
		if pgrep -x "pipewire" > /dev/null; then
                         echo -e "\e[38;5;75mPipewire ya esta en ejecucion ..\e[0m"
		else
			sudo apt install -y pipewire-audio-client-libraries pipewire-pulse
			systemctl --user daemon-reexec
			systemctl --user daemon-reload
			systemctl --user unmask pipewire.service
                        systemctl --user unmask pipewire.socket
                        systemctl --user unmask pipewire-pulse.service
                        systemctl --user unmask pipewire-pulse.socket

			systemctl --user enable pipewire.service
                        systemctl --user enable pipewire.socket
                        systemctl --user enable pipewire-pulse.service
                        systemctl --user enable pipewire-pulse.socket

			systemctl --user start pipewire.service
                        systemctl --user start pipewire.socket
                        systemctl --user start pipewire-pulse.service
                        systemctl --user start pipewire-pulse.socket
			echo -e "\e[38;5;75mPipewire se ha iniciado ..\e[0m"
		fi
		;;
                8) echo "Consultando logs ..";;
                8.1) echo "Consultando logs por fecha ..";;
                8.2) echo "Consultando logs por tipo ..";;
		9) echo $'\e[32mSaliendo del script..\e[0m'
		exit 0 ;;
		*) echo "Opcion no valida, intentalo de nuevo" ;;
	esac
	read -p $'\e[32mPresione enter para volver al menu\e[0m'
	done
}

menu

